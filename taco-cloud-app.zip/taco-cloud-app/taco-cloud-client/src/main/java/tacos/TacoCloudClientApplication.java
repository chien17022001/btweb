package tacos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TacoCloudClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(TacoCloudClientApplication.class, args);
    }

}
