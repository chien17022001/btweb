package tacos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TacoCloudApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(TacoCloudApiApplication.class, args);
    }

}
